.. _whatsnew:

.. currentmodule:: seaborn

What's new in the package
=========================

.. include:: releases/v0.8.1.txt

.. include:: releases/v0.8.0.txt

.. include:: releases/v0.7.1.txt

.. include:: releases/v0.7.0.txt

.. include:: releases/v0.6.0.txt

.. include:: releases/v0.5.1.txt

.. include:: releases/v0.5.0.txt

.. include:: releases/v0.4.0.txt

.. include:: releases/v0.3.1.txt

.. include:: releases/v0.3.0.txt

.. include:: releases/v0.2.1.txt

.. include:: releases/v0.2.0.txt

